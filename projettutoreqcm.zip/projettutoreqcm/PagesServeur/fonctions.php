<?php

function bdd(){ // pour se connecter à la base de données (bdd)
  require("parametres.php");
  $where = 'local';
  if ($where == 'local') {
    try { $bdd = new PDO("mysql:host=localhost;dbname=".$base."","root",$mdp); }
    catch (Exeption $e) { die('Erreur : ' .$e->getMessage())  or die(print_r($bdd->errorInfo())); }
  } else {
    echo "ERREUR";
  }
  return $bdd;
}

?>
