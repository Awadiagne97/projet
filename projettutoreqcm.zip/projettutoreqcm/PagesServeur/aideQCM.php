<!DOCTYPE html>
<html lang="en">

			<head>
				<meta charset="UTF-8">
				<title>EASY TEST | AIDE</title>
				<link rel="stylesheet" href="style/index.css">

				<link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">

			</head>
			<body background="images/fond-test.jpg">
					  <header class="top">
							<nav class="navigation container">
								<a href="#" class="logo">EASY TEST</a>
							
					  </header>


					<div id='infoAMC' class="form">


							

								<h2 style="color:#48C9B0;">La correction de vos copies vous prend trop de temps ?</h2><br>
							<p>
								EASY TEST vous permet de rapidement créer un questionnaire à choix multiples,  puis de le corriger en quelque minutes seulement.

							</p>

							<p>

								Une fois inscrit, vous bénéficiez d'un outil pédagogique indispensable.<br>

								<ol>

									<li>Créez un QCM en quelques clics, déterminez le nombre de questions, le nombres de réponses, le temps de l'épreuve ainsi que le nombre d'exemplaires.<br></li>

									<li>Générez le corrigé et les sujets au format PDF afin de les imprimer, les questions ne seront jamais dans le même ordres selon les copies.<br></li>

									<li>Corrigez les copies en insérant les scans et le fichier csv contenant les noms, prénoms et numéros des étudiants. La correction se fait automatiquement et attribue une note à chaque étudiant.

								</ol>

							</p>

					</div>		
			</body>
</html>
