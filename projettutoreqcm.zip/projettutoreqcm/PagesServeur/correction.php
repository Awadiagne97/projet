<?php
	session_start();
	$nomQCM=$_SESSION['nomQuestionnaire'];
?>
<h1>Correction du QCM</h1>
<form action="" method="post">
	<fieldset>
		<legend>
			<strong>Insertion du fichier csv contenant les identifiants des étudiants</strong>
		</legend>
		<p>Veuillez sélectionner le fichier csv contenant les informations sur les étudiants, la première ligne du fichier étant: "Nom,Prenom,NumeroEtudiant" 
		 (puis 1 ligne pour chaque étudiant du type nom,prenom,numero)</p>
		 <form method="POST" action="">
			<input type="file" name="fichier">
			<input type="submit" name="ok" value="Valider le fichier">
		</form>
	</fieldset>
	<fieldset>
		<legend>
			<strong>Insertion des scans</strong></legend>
			  <form method="post" action="" enctype="multipart/form-data">
				<input name="uploads[]" type="file" multiple>
				<input type="submit" value="Envoyer les scans" name="envoyer">
			  </form>
	</fieldset>
	<br/><br/>
</form>
<form action="" method="post">
	<input type="submit" value="Valider les informations" name="validation">
</form>

<?php 
	require("parametres.php");
	$fichier=0;
	$csv=0;		
	function affichage($fic){
		echo"<p>";
		$ligne=0;
		 while($tab=fgetcsv($fic,1024,',')){
			$ligne++;
			echo "<tr>";
			if($ligne==1){
				if($tab[0]!="Nom" || $tab[1]!="Prenom" || $tab[2]!="NumeroEtudiant"){
					echo "ERREUR: LA PREMIERE LIGNE DU FICHIER DOIT ÊTRE: Nom,Prenom,NumeroEtudiant";
					break;
				}		
				echo "<th>Nom</th><th>Prénom</th><th>Numéro de l'étudiant</th>";
				$ligne++;
			}
			else{
				foreach($tab as $champs)
					echo "<td>$champs</td>";
			}
			echo "</tr>";	
		}
		echo "</table>";
		echo"</p>";
	}
	//envoi des scans dans le répertoire scans du dossier dont le nom est celui du questionnaire (cad le projet AMC)
	if(isset($_POST['envoyer'])) {
		$uploaddir = $dossierQCM.$nomQCM."/scans/";
		$i = 0;
		foreach ($_FILES['uploads'] as $file) {
		  $uploadfile = $uploaddir.basename($_FILES['uploads']['name'][$i]);
		  move_uploaded_file($_FILES['uploads']['tmp_name'][$i], $uploadfile);
		  $i++;
		}
	}
	//affichage des infos 
	if( (isset($_POST['fichier']) && !empty($_POST['fichier'])) || $csv==1){
		$csv=1;
		echo "<p>Si les informations sont correctes, cliquez sur Valider les informations.</p>";
		if(file_exists($dossierQCM.$nomQCM."/".$_POST['fichier'])){
			$fichier=$dossierQCM.$nomQCM."/".$_POST['fichier'];
			$fic = fopen($fichier, "r");
			echo "<p>Voici les informations concernant les étudiants qui vont passer l'examen:</p>";
			echo "<table border='1' cellpadding='15'><tr>";
			affichage($fic);
			fclose($fic);
			$commande="sudo -u $utilisateur chmod 777 -R $dossierQCM";
			exec($commande);
			$_SESSION['fichierCSV']=$fichier;
		}
	}
	if(isset($_POST['validation'])){
		header("Location:resultats.php");
		
	}
?>
<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
    <title>AMC MAKER</title>
    <link rel="stylesheet" href="style/style-pageUser.css">

    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">

</head>

    <header class="top">
        <nav class="navigation container">
            <a href="index.php" class="logo">AMC MAKER</a>
            <ul class="nav-right">


				<form action='' method='post'>
					<input type="submit" id="bdeconnexion" name="deco" value="Déconnexion"/>
				</form>
					 <li><a href="aide/aidePageUtilisateur.html">Aide</a></li>
						<li><a href="pageCompte.php">Compte</a></li>
						 <li><a href="correction.php">Correction</a></li>
			</ul>
		</nav>
    </header>
	
<body></body>
</html>
