<?php
	//Mettez vos informations pour la connexion mysql et le dossier représentant le projet AMC qui contiendra les fichiers
	$serveur = "localhost";
    	$login = "root";
	$mdp = "";
	$base = "base";
	$dossierQCM="/var/www/html/Projets-QCM/";
	$utilisateur="solimani";
?>
